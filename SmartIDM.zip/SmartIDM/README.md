# مدير التحميلات الذكي (SmartIDM & Video Downloader)

مشروع تطبيق أندرويد متكامل مبني بلغة **Kotlin** وواجهة **Jetpack Compose (Material Design 3)** مع دعم كامل للوضع الليلي (Dark Mode) واللغة العربية (RTL).

## المميزات المعمارية المنفذة بالكامل
1. **استخراج الفيديوهات والصوتيات (`YoutubeDL-Android` + `FFmpeg`)**:
   - تحليل الروابط من المنصات (يوتيوب، تيك توك، فيسبوك، إنستغرام) أو الروابط المباشرة.
   - نافذة سفلية (`ModalBottomSheet`) لاختيار الدقة (`1080p Full HD`, `720p HD`, `480p SD`) أو استخراج الصوت بصيغة `MP3 320kbps`.
   - استقبال الروابط مباشرة من قائمة المشاركة (`Intent.ACTION_SEND`) في الهاتف.
2. **محرك تحميل متعدد القنوات (`MultiThreadDownloader` - IDM Engine)**:
   - تقسيم الملفات عبر بروتوكول `HTTP Range` باستخدام `OkHttp` و `Coroutines` (`1, 2, 4, 8` قنوات متوازية).
   - كتابة الأجزاء مباشرة في مواقعها عبر `RandomAccessFile` مع حفظ حالة كل جزء لدعم الإيقاف المؤقت (`Pause`) والاستئناف (`Resume`) والإلغاء (`Cancel`).
   - مربوط بخدمة أمامية (`DownloadForegroundService` من نوع `dataSync`) لضمان استمرار التحميل في الخلفية مع إشعار حي بالسرعة ونسبة التقدم.
3. **المتصفح المدمج لالتقاط الفيديو (`BrowserSnifferScreen` - Video Sniffer)**:
   - متصفح `WebView` متكامل يعترض طلبات الشبكة عبر `shouldInterceptRequest` و `onLoadResource` لرصد ملفات الفيديو والبث (`.mp4`, `.m3u8`, `.webm`, `.mp3`, `.m4a`).
   - زر عائم (`ExtendedFloatingActionButton`) يتغير لونه تلقائياً ويعرض عداد الفيديوهات المكتشفة لتحميلها بضغطة واحدة.

## طريقة استخراج ملف `app-debug.apk`
### الطريقة الأولى: عبر GitHub Actions (سحابياً بضغطة واحدة)
1. ارفع محتويات هذا المشروع إلى مستودع GitHub جديد.
2. سيقوم ملف `.github/workflows/build.yml` تلقائياً بتثبيت JDK 17 و Android SDK 34 وتشغيل `gradle assembleDebug`.
3. حمّل ملف `app-debug.apk` الجاهز للتثبيت من قسم **Actions -> Artifacts -> SmartIDM-app-debug-apk**.

### الطريقة الثانية: محلياً عبر Android Studio أو سطر الأوامر
```bash
./gradlew assembleDebug
```
ستجد ملف الـ APK الجاهز في المسار:
`app/build/outputs/apk/debug/app-debug.apk`
