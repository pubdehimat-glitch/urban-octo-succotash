package com.smartidm.downloader.model

import java.util.UUID

enum class DownloadStatus(val arabicLabel: String) {
    QUEUED("في الانتظار"),
    DOWNLOADING("جارٍ التحميل"),
    MERGING("جارٍ الدمج والتحويل (FFmpeg)"),
    PAUSED("متوقف مؤقتاً"),
    COMPLETED("مكتمل"),
    FAILED("فشل التحميل"),
    CANCELED("تم الإلغاء")
}

enum class MediaType(val label: String) {
    VIDEO_MP4("فيديو MP4"),
    AUDIO_MP3("صوت MP3"),
    HLS_STREAM("بث M3U8"),
    DIRECT_FILE("ملف مباشر")
}

data class VideoFormatOption(
    val id: String,
    val title: String,
    val resolution: String,
    val extension: String,
    val formatSelector: String,
    val isAudioOnly: Boolean,
    val estimatedSizeBytes: Long = -1L,
    val directUrl: String? = null
)

data class ExtractedMediaInfo(
    val originalUrl: String,
    val title: String,
    val uploader: String,
    val durationSeconds: Long,
    val thumbnailUrl: String?,
    val isDirectFile: Boolean,
    val formats: List<VideoFormatOption>
)

data class ChunkRange(
    val index: Int,
    val startByte: Long,
    val endByte: Long,
    val downloadedBytes: Long = 0L
) {
    val currentOffset: Long
        get() = startByte + downloadedBytes

    val isComplete: Boolean
        get() = currentOffset > endByte
}

data class DownloadTask(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val sourceUrl: String,
    val directOrStreamUrl: String,
    val fileName: String,
    val destinationPath: String,
    val formatLabel: String,
    val formatSelector: String,
    val mediaType: MediaType,
    val useYoutubeDlEngine: Boolean,
    val totalBytes: Long = -1L,
    val downloadedBytes: Long = 0L,
    val progressPercent: Float = 0f,
    val speedBytesPerSec: Long = 0L,
    val etaSeconds: Long = -1L,
    val threadCount: Int = 4,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val statusDetail: String = "في قائمة الانتظار",
    val errorMessage: String? = null,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val chunks: List<ChunkRange> = emptyList()
)

data class SniffedVideoStream(
    val id: String = UUID.randomUUID().toString(),
    val url: String,
    val pageUrl: String,
    val pageTitle: String,
    val extension: String,
    val mimeType: String,
    val qualityHint: String,
    val contentLength: Long = -1L,
    val detectedAtMillis: Long = System.currentTimeMillis()
)
