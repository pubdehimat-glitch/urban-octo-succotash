package com.smartidm.downloader.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.smartidm.downloader.model.SniffedVideoStream
import java.net.URI

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserSnifferScreen(
    initialUrl: String,
    sniffedStreams: List<SniffedVideoStream>,
    onUrlCommitted: (String) -> Unit,
    onStreamDetected: (SniffedVideoStream) -> Unit,
    onDownloadSniffedStream: (SniffedVideoStream) -> Unit,
    onClearSniffedStreams: () -> Unit
) {
    var addressBarText by remember(initialUrl) { mutableStateOf(initialUrl) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var pageTitle by remember { mutableStateOf("متصفح التقاط الفيديو") }
    var loadProgress by remember { mutableIntStateOf(0) }
    var showSniffedSheet by remember { mutableStateOf(false) }

    val hasDetectedVideos = sniffedStreams.isNotEmpty()
    val fabContainerColor by animateColorAsState(
        targetValue = if (hasDetectedVideos) {
            MaterialTheme.colorScheme.primary
        } else {
            MaterialTheme.colorScheme.surfaceVariant
        },
        label = "fabColorAnimation"
    )
    val fabContentColor by animateColorAsState(
        targetValue = if (hasDetectedVideos) {
            MaterialTheme.colorScheme.onPrimary
        } else {
            MaterialTheme.colorScheme.onSurfaceVariant
        },
        label = "fabContentColorAnimation"
    )

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showSniffedSheet = true },
                containerColor = fabContainerColor,
                contentColor = fabContentColor,
                icon = {
                    BadgedBox(
                        badge = {
                            if (hasDetectedVideos) {
                                Badge(
                                    containerColor = Color(0xFFF43F5E),
                                    contentColor = Color.White
                                ) {
                                    Text("${sniffedStreams.size}")
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (hasDetectedVideos) Icons.Default.CloudDownload else Icons.Default.Radar,
                            contentDescription = "ملتقط الفيديو"
                        )
                    }
                },
                text = {
                    Text(
                        text = if (hasDetectedVideos) {
                            "تحميل الفيديو المكتشف (${sniffedStreams.size})"
                        } else {
                            "رادار الفيديو نشط"
                        },
                        fontWeight = FontWeight.Bold
                    )
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // شريط العنوان وأزرار التحكم بالمتصفح
            Surface(
                tonalElevation = 3.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        IconButton(onClick = {
                            if (webViewRef?.canGoBack() == true) webViewRef?.goBack()
                        }) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "رجوع")
                        }

                        IconButton(onClick = {
                            if (webViewRef?.canGoForward() == true) webViewRef?.goForward()
                        }) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "تقدم")
                        }

                        OutlinedTextField(
                            value = addressBarText,
                            onValueChange = { addressBarText = it },
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            placeholder = { Text("ابحث أو أدخل عنوان موقع...") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Public,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(24.dp),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                            keyboardActions = KeyboardActions(
                                onGo = {
                                    val formatted = normalizeBrowserInput(addressBarText)
                                    addressBarText = formatted
                                    onUrlCommitted(formatted)
                                    webViewRef?.loadUrl(formatted)
                                }
                            )
                        )

                        IconButton(onClick = {
                            val formatted = normalizeBrowserInput(addressBarText)
                            addressBarText = formatted
                            onUrlCommitted(formatted)
                            webViewRef?.loadUrl(formatted)
                        }) {
                            Icon(imageVector = Icons.Default.Search, contentDescription = "انتقال")
                        }

                        IconButton(onClick = { webViewRef?.reload() }) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = "تحديث")
                        }
                    }

                    if (loadProgress in 1..99) {
                        Spacer(modifier = Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { loadProgress / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp)
                        )
                    }
                }
            }

            // شاشة WebView المدمجة مع اعتراض طلبات الشبكة (shouldInterceptRequest)
            AndroidView(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                factory = { context ->
                    WebView(context).apply {
                        settings.apply {
                            javaScriptEnabled = true
                            domStorageEnabled = true
                            mediaPlaybackRequiresUserGesture = false
                            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            loadsImagesAutomatically = true
                            useWideViewPort = true
                            loadWithOverviewMode = true
                            setSupportZoom(true)
                            builtInZoomControls = true
                            displayZoomControls = false
                        }

                        webChromeClient = object : WebChromeClient() {
                            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                loadProgress = newProgress
                            }

                            override fun onReceivedTitle(view: WebView?, title: String?) {
                                if (!title.isNullOrBlank()) {
                                    pageTitle = title
                                }
                            }
                        }

                        webViewClient = object : WebViewClient() {
                            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                super.onPageStarted(view, url, favicon)
                                if (!url.isNullOrBlank()) {
                                    addressBarText = url
                                }
                            }

                            override fun onLoadResource(view: WebView?, url: String?) {
                                super.onLoadResource(view, url)
                                if (url != null) {
                                    inspectPotentialMediaUrl(
                                        candidateUrl = url,
                                        acceptHeader = "",
                                        currentPageUrl = view?.url.orEmpty(),
                                        currentTitle = pageTitle,
                                        onDetected = onStreamDetected
                                    )
                                }
                            }

                            override fun shouldInterceptRequest(
                                view: WebView?,
                                request: WebResourceRequest?
                            ): WebResourceResponse? {
                                val reqUrl = request?.url?.toString()
                                if (!reqUrl.isNullOrBlank()) {
                                    val accept = request.requestHeaders["Accept"].orEmpty()
                                    inspectPotentialMediaUrl(
                                        candidateUrl = reqUrl,
                                        acceptHeader = accept,
                                        currentPageUrl = addressBarText,
                                        currentTitle = pageTitle,
                                        onDetected = onStreamDetected
                                    )
                                }
                                return super.shouldInterceptRequest(view, request)
                            }
                        }

                        loadUrl(initialUrl)
                        webViewRef = this
                    }
                }
            )
        }
    }

    // نافذة الفيديوهات الملتقطة (Sniffed Videos Bottom Sheet)
    if (showSniffedSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        ModalBottomSheet(
            onDismissRequest = { showSniffedSheet = false },
            sheetState = sheetState
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "الفيديوهات والبث المكتشف في الصفحة (${sniffedStreams.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "اضغط على أي ملف فيديو لبدء تحميله فوراً بضغطة واحدة",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (sniffedStreams.isNotEmpty()) {
                        TextButton(onClick = onClearSniffedStreams) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("مسح")
                        }
                    }
                }

                HorizontalDivider()

                if (sniffedStreams.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "لم يتم رصد ملفات فيديو (.mp4, .m3u8, .webm) بعد. قم بتشغيل الفيديو داخل الصفحة ليتم التقاطه تلقائياً.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.height(340.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(sniffedStreams, key = { it.id }) { stream ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onDownloadSniffedStream(stream)
                                        showSniffedSheet = false
                                    },
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(40.dp)
                                                .clip(CircleShape)
                                                .background(MaterialTheme.colorScheme.primaryContainer),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.VideoFile,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        Column {
                                            Text(
                                                text = stream.pageTitle.ifBlank { "ملف فيديو مكتشف" },
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "${stream.extension.uppercase()} • ${stream.qualityHint}",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Text(
                                                text = stream.url,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }

                                    Surface(
                                        color = MaterialTheme.colorScheme.primary,
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Download,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.onPrimary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Text(
                                                text = "تحميل",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = MaterialTheme.colorScheme.onPrimary,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun normalizeBrowserInput(input: String): String {
    val trimmed = input.trim()
    if (trimmed.startsWith("http://", ignoreCase = true) || trimmed.startsWith("https://", ignoreCase = true)) {
        return trimmed
    }
    return if (trimmed.contains(".") && !trimmed.contains(" ")) {
        "https://$trimmed"
    } else {
        "https://www.google.com/search?q=${ java.net.URLEncoder.encode(trimmed, "UTF-8") }"
    }
}

private fun inspectPotentialMediaUrl(
    candidateUrl: String,
    acceptHeader: String,
    currentPageUrl: String,
    currentTitle: String,
    onDetected: (SniffedVideoStream) -> Unit
) {
    val lowerUrl = candidateUrl.lowercase()
    if (lowerUrl.startsWith("blob:") || lowerUrl.startsWith("data:")) return
    // Ignore tiny tracking pixels or segment fragments (.ts chunks) when master .m3u8 is targeted
    if (lowerUrl.endsWith(".png") || lowerUrl.endsWith(".jpg") || lowerUrl.endsWith(".css") || lowerUrl.endsWith(".js")) {
        return
    }

    val cleanPath = runCatching { URI(candidateUrl).path ?: "" }
        .getOrDefault(candidateUrl.substringBefore("?"))
        .lowercase()

    val detectedExt = when {
        cleanPath.endsWith(".mp4") || lowerUrl.contains(".mp4?") || lowerUrl.contains("mime=video/mp4") -> "mp4"
        cleanPath.endsWith(".m3u8") || lowerUrl.contains(".m3u8?") || lowerUrl.contains("mpegurl") -> "m3u8"
        cleanPath.endsWith(".webm") || lowerUrl.contains(".webm?") || lowerUrl.contains("mime=video/webm") -> "webm"
        cleanPath.endsWith(".m4a") || lowerUrl.contains(".m4a?") -> "m4a"
        cleanPath.endsWith(".mp3") || lowerUrl.contains(".mp3?") -> "mp3"
        acceptHeader.contains("video/", ignoreCase = true) && (lowerUrl.contains("video") || lowerUrl.contains("stream")) -> "mp4"
        else -> null
    } ?: return

    val qualityHint = when {
        lowerUrl.contains("1080") -> "1080p Full HD"
        lowerUrl.contains("720") -> "720p HD"
        lowerUrl.contains("480") -> "480p SD"
        lowerUrl.contains("360") -> "360p"
        detectedExt == "m3u8" -> "بث متكيف HLS"
        else -> "فيديو مباشر"
    }

    val mimeType = when (detectedExt) {
        "m3u8" -> "application/x-mpegURL"
        "webm" -> "video/webm"
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        else -> "video/mp4"
    }

    onDetected(
        SniffedVideoStream(
            url = candidateUrl,
            pageUrl = currentPageUrl,
            pageTitle = currentTitle,
            extension = detectedExt,
            mimeType = mimeType,
            qualityHint = qualityHint
        )
    )
}
