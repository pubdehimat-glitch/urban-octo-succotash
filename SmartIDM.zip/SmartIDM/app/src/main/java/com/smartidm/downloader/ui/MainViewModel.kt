package com.smartidm.downloader.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smartidm.downloader.DownloaderApp
import com.smartidm.downloader.data.DownloadRepository
import com.smartidm.downloader.engine.VideoExtractorEngine
import com.smartidm.downloader.model.DownloadStatus
import com.smartidm.downloader.model.DownloadTask
import com.smartidm.downloader.model.ExtractedMediaInfo
import com.smartidm.downloader.model.MediaType
import com.smartidm.downloader.model.SniffedVideoStream
import com.smartidm.downloader.model.VideoFormatOption
import com.smartidm.downloader.service.DownloadForegroundService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val extractorEngine = VideoExtractorEngine(
        context = application.applicationContext,
        scope = viewModelScope,
        onTaskChanged = {}
    )

    val tasks: StateFlow<List<DownloadTask>> = DownloadRepository.tasks
    val sniffedStreams: StateFlow<List<SniffedVideoStream>> = DownloadRepository.sniffedStreams
    val sharedIncomingUrl: StateFlow<String?> = DownloadRepository.sharedIncomingUrl

    val isEngineReady: StateFlow<Boolean> = DownloaderApp.instance.isEngineReady
    val engineStatusMessage: StateFlow<String> = DownloaderApp.instance.engineStatusMessage

    private val _selectedTabIndex = MutableStateFlow(0)
    val selectedTabIndex: StateFlow<Int> = _selectedTabIndex.asStateFlow()

    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _analysisError = MutableStateFlow<String?>(null)
    val analysisError: StateFlow<String?> = _analysisError.asStateFlow()

    private val _extractedMedia = MutableStateFlow<ExtractedMediaInfo?>(null)
    val extractedMedia: StateFlow<ExtractedMediaInfo?> = _extractedMedia.asStateFlow()

    private val _selectedThreadCount = MutableStateFlow(4)
    val selectedThreadCount: StateFlow<Int> = _selectedThreadCount.asStateFlow()

    private val _currentBrowserUrl = MutableStateFlow("https://www.dailymotion.com")
    val currentBrowserUrl: StateFlow<String> = _currentBrowserUrl.asStateFlow()

    init {
        DownloadRepository.loadPersistedTasks(application.applicationContext)
    }

    fun selectTab(index: Int) {
        _selectedTabIndex.value = index
    }

    fun onUrlInputChange(newValue: String) {
        _urlInput.value = newValue
        _analysisError.value = null
    }

    fun setThreadCount(threads: Int) {
        _selectedThreadCount.value = threads.coerceIn(1, 8)
    }

    fun updateBrowserUrl(url: String) {
        _currentBrowserUrl.value = url
    }

    fun consumeSharedUrl(url: String) {
        val extracted = VideoExtractorEngine.extractFirstUrl(url) ?: url
        _urlInput.value = extracted
        _selectedTabIndex.value = 0
        DownloadRepository.setSharedIncomingUrl(null)
        analyzeCurrentUrl(extracted)
    }

    fun analyzeCurrentUrl(overrideUrl: String? = null) {
        val targetUrl = (overrideUrl ?: _urlInput.value).trim()
        if (targetUrl.isEmpty()) {
            _analysisError.value = "يرجى لصق أو كتابة رابط الفيديو أو الملف أولاً"
            return
        }

        viewModelScope.launch {
            _isAnalyzing.value = true
            _analysisError.value = null
            val result = extractorEngine.analyzeUrl(targetUrl)
            _isAnalyzing.value = false
            result.onSuccess { info ->
                _extractedMedia.value = info
            }.onFailure { err ->
                _analysisError.value = err.localizedMessage ?: "تعذر تحليل الرابط المدخل"
            }
        }
    }

    fun dismissExtractorSheet() {
        _extractedMedia.value = null
    }

    fun enqueueDownloadFromOption(media: ExtractedMediaInfo, option: VideoFormatOption) {
        val context = getApplication<Application>().applicationContext
        val downloadDir = DownloadRepository.getDownloadDirectory(context)
        val cleanTitle = VideoExtractorEngine.sanitizeFileName(media.title)
        val fileName = "${cleanTitle}_${option.resolution.replace(" ", "_")}.${option.extension}"
        val destinationFile = File(downloadDir, fileName)

        val useYtDlp = !media.isDirectFile || option.directUrl == null || option.isAudioOnly
        val mediaType = when {
            option.isAudioOnly -> MediaType.AUDIO_MP3
            media.isDirectFile -> MediaType.DIRECT_FILE
            else -> MediaType.VIDEO_MP4
        }

        val newTask = DownloadTask(
            title = media.title,
            sourceUrl = media.originalUrl,
            directOrStreamUrl = option.directUrl ?: media.originalUrl,
            fileName = fileName,
            destinationPath = destinationFile.absolutePath,
            formatLabel = option.resolution,
            formatSelector = option.formatSelector,
            mediaType = mediaType,
            useYoutubeDlEngine = useYtDlp,
            totalBytes = option.estimatedSizeBytes,
            threadCount = _selectedThreadCount.value,
            status = DownloadStatus.QUEUED,
            statusDetail = "جارٍ بدء التحميل..."
        )

        DownloadRepository.addOrUpdateTask(context, newTask)
        DownloadForegroundService.sendAction(
            context = context,
            action = DownloadForegroundService.ACTION_START_OR_RESUME,
            taskId = newTask.id
        )

        _extractedMedia.value = null
        _selectedTabIndex.value = 1
    }

    fun enqueueSniffedStream(stream: SniffedVideoStream) {
        val context = getApplication<Application>().applicationContext
        val downloadDir = DownloadRepository.getDownloadDirectory(context)
        val baseTitle = VideoExtractorEngine.sanitizeFileName(
            stream.pageTitle.ifBlank { "فيديو_المتصفح_${System.currentTimeMillis() / 1000}" }
        )
        val isHls = stream.extension.equals("m3u8", ignoreCase = true) ||
            stream.mimeType.contains("mpegurl", ignoreCase = true)
        val finalExt = if (isHls) "mp4" else stream.extension.ifBlank { "mp4" }
        val fileName = "${baseTitle}_${System.currentTimeMillis() % 10000}.$finalExt"
        val destFile = File(downloadDir, fileName)

        val newTask = DownloadTask(
            title = baseTitle,
            sourceUrl = stream.url,
            directOrStreamUrl = stream.url,
            fileName = fileName,
            destinationPath = destFile.absolutePath,
            formatLabel = "${stream.extension.uppercase()} (${stream.qualityHint})",
            formatSelector = "best",
            mediaType = if (isHls) MediaType.HLS_STREAM else MediaType.VIDEO_MP4,
            useYoutubeDlEngine = isHls,
            totalBytes = stream.contentLength,
            threadCount = _selectedThreadCount.value,
            status = DownloadStatus.QUEUED,
            statusDetail = "تم التقاط الفيديو من المتصفح - جارٍ التحميل..."
        )

        DownloadRepository.addOrUpdateTask(context, newTask)
        DownloadForegroundService.sendAction(
            context = context,
            action = DownloadForegroundService.ACTION_START_OR_RESUME,
            taskId = newTask.id
        )
        _selectedTabIndex.value = 1
    }

    fun pauseTask(taskId: String) {
        DownloadForegroundService.sendAction(
            context = getApplication(),
            action = DownloadForegroundService.ACTION_PAUSE,
            taskId = taskId
        )
    }

    fun resumeTask(taskId: String) {
        DownloadForegroundService.sendAction(
            context = getApplication(),
            action = DownloadForegroundService.ACTION_START_OR_RESUME,
            taskId = taskId
        )
    }

    fun cancelTask(taskId: String) {
        DownloadForegroundService.sendAction(
            context = getApplication(),
            action = DownloadForegroundService.ACTION_CANCEL,
            taskId = taskId
        )
    }

    fun deleteTask(taskId: String, deleteFileFromDisk: Boolean) {
        DownloadRepository.removeTask(getApplication(), taskId, deleteFileFromDisk)
    }

    fun registerSniffedStream(stream: SniffedVideoStream) {
        DownloadRepository.addSniffedStream(stream)
    }

    fun clearSniffedStreams() {
        DownloadRepository.clearSniffedStreams()
    }
}
