package com.smartidm.downloader

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.smartidm.downloader.data.DownloadRepository
import com.smartidm.downloader.model.DownloadStatus
import com.smartidm.downloader.ui.MainViewModel
import com.smartidm.downloader.ui.screens.BrowserSnifferScreen
import com.smartidm.downloader.ui.screens.DownloadsScreen
import com.smartidm.downloader.ui.screens.ExtractorScreen
import com.smartidm.downloader.ui.theme.SmartIDMTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNecessaryPermissions()
        handleIncomingShareIntent(intent)

        setContent {
            SmartIDMTheme {
                SmartIdmMainApp(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingShareIntent(intent)
    }

    private fun handleIncomingShareIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!sharedText.isNullOrBlank()) {
                DownloadRepository.setSharedIncomingUrl(sharedText)
            }
        }
    }

    private fun requestNecessaryPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            permissionsToRequest.add(Manifest.permission.READ_MEDIA_VIDEO)
            permissionsToRequest.add(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
                permissionsToRequest.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }

        val missing = permissionsToRequest.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartIdmMainApp(viewModel: MainViewModel) {
    val selectedTab by viewModel.selectedTabIndex.collectAsStateWithLifecycle()
    val urlInput by viewModel.urlInput.collectAsStateWithLifecycle()
    val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
    val analysisError by viewModel.analysisError.collectAsStateWithLifecycle()
    val isEngineReady by viewModel.isEngineReady.collectAsStateWithLifecycle()
    val engineStatusMessage by viewModel.engineStatusMessage.collectAsStateWithLifecycle()
    val selectedThreadCount by viewModel.selectedThreadCount.collectAsStateWithLifecycle()
    val extractedMedia by viewModel.extractedMedia.collectAsStateWithLifecycle()
    val tasks by viewModel.tasks.collectAsStateWithLifecycle()
    val sniffedStreams by viewModel.sniffedStreams.collectAsStateWithLifecycle()
    val browserUrl by viewModel.currentBrowserUrl.collectAsStateWithLifecycle()
    val sharedIncomingUrl by viewModel.sharedIncomingUrl.collectAsStateWithLifecycle()

    LaunchedEffect(sharedIncomingUrl) {
        val incoming = sharedIncomingUrl
        if (!incoming.isNullOrBlank()) {
            viewModel.consumeSharedUrl(incoming)
        }
    }

    val activeDownloadCount = tasks.count {
        it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.MERGING
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = when (selectedTab) {
                            0 -> "مدير التحميلات الذكي IDM"
                            1 -> "إدارة التحميلات (${tasks.size})"
                            else -> "المتصفح الذكي وملتقط الفيديو"
                        },
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { viewModel.selectTab(0) },
                    icon = { Icon(imageVector = Icons.Default.Home, contentDescription = null) },
                    label = { Text("الرئيسية") }
                )

                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { viewModel.selectTab(1) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (activeDownloadCount > 0) {
                                    Badge { Text("$activeDownloadCount") }
                                }
                            }
                        ) {
                            Icon(imageVector = Icons.Default.CloudDownload, contentDescription = null)
                        }
                    },
                    label = { Text("التحميلات") }
                )

                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { viewModel.selectTab(2) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (sniffedStreams.isNotEmpty()) {
                                    Badge { Text("${sniffedStreams.size}") }
                                }
                            }
                        ) {
                            Icon(imageVector = Icons.Default.Explore, contentDescription = null)
                        }
                    },
                    label = { Text("ملتقط الفيديو") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> ExtractorScreen(
                    urlInput = urlInput,
                    isAnalyzing = isAnalyzing,
                    analysisError = analysisError,
                    isEngineReady = isEngineReady,
                    engineStatusMessage = engineStatusMessage,
                    selectedThreadCount = selectedThreadCount,
                    extractedMedia = extractedMedia,
                    onUrlChange = viewModel::onUrlInputChange,
                    onAnalyzeClick = viewModel::analyzeCurrentUrl,
                    onThreadCountChange = viewModel::setThreadCount,
                    onFormatSelected = viewModel::enqueueDownloadFromOption,
                    onDismissSheet = viewModel::dismissExtractorSheet
                )

                1 -> DownloadsScreen(
                    tasks = tasks,
                    onPause = viewModel::pauseTask,
                    onResume = viewModel::resumeTask,
                    onCancel = viewModel::cancelTask,
                    onDelete = { id -> viewModel.deleteTask(id, deleteFileFromDisk = false) }
                )

                2 -> BrowserSnifferScreen(
                    initialUrl = browserUrl,
                    sniffedStreams = sniffedStreams,
                    onUrlCommitted = viewModel::updateBrowserUrl,
                    onStreamDetected = viewModel::registerSniffedStream,
                    onDownloadSniffedStream = viewModel::enqueueSniffedStream,
                    onClearSniffedStreams = viewModel::clearSniffedStreams
                )
            }
        }
    }
}
