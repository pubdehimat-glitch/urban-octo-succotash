package com.smartidm.downloader.data

import android.content.Context
import android.os.Environment
import com.smartidm.downloader.model.ChunkRange
import com.smartidm.downloader.model.DownloadStatus
import com.smartidm.downloader.model.DownloadTask
import com.smartidm.downloader.model.SniffedVideoStream
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object DownloadRepository {

    private const val STATE_FILE_NAME = "downloads_state_v1.json"

    private val _tasks = MutableStateFlow<List<DownloadTask>>(emptyList())
    val tasks: StateFlow<List<DownloadTask>> = _tasks.asStateFlow()

    private val _sniffedStreams = MutableStateFlow<List<SniffedVideoStream>>(emptyList())
    val sniffedStreams: StateFlow<List<SniffedVideoStream>> = _sniffedStreams.asStateFlow()

    private val _sharedIncomingUrl = MutableStateFlow<String?>(null)
    val sharedIncomingUrl: StateFlow<String?> = _sharedIncomingUrl.asStateFlow()

    fun setSharedIncomingUrl(url: String?) {
        _sharedIncomingUrl.value = url
    }

    fun getDownloadDirectory(context: Context): File {
        val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val smartIdmDir = File(publicDownloads, "SmartIDM")
        if (smartIdmDir.exists() || smartIdmDir.mkdirs()) {
            return smartIdmDir
        }
        val appExternal = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "SmartIDM")
        appExternal.mkdirs()
        return appExternal
    }

    fun addOrUpdateTask(context: Context, task: DownloadTask) {
        _tasks.update { currentList ->
            val index = currentList.indexOfFirst { it.id == task.id }
            if (index >= 0) {
                currentList.toMutableList().apply { set(index, task) }
            } else {
                listOf(task) + currentList
            }
        }
        persistTasks(context)
    }

    fun updateTask(context: Context, taskId: String, persistImmediately: Boolean = false, transform: (DownloadTask) -> DownloadTask) {
        _tasks.update { currentList ->
            currentList.map { task ->
                if (task.id == taskId) transform(task) else task
            }
        }
        if (persistImmediately) {
            persistTasks(context)
        }
    }

    fun getTask(taskId: String): DownloadTask? {
        return _tasks.value.find { it.id == taskId }
    }

    fun removeTask(context: Context, taskId: String, deleteFile: Boolean) {
        val target = getTask(taskId)
        if (deleteFile && target != null) {
            runCatching { File(target.destinationPath).delete() }
        }
        _tasks.update { list -> list.filterNot { it.id == taskId } }
        persistTasks(context)
    }

    fun addSniffedStream(stream: SniffedVideoStream) {
        _sniffedStreams.update { current ->
            val normalizedUrl = stream.url.substringBefore("#")
            if (current.any { it.url.substringBefore("#") == normalizedUrl }) {
                current
            } else {
                listOf(stream) + current
            }
        }
    }

    fun clearSniffedStreams() {
        _sniffedStreams.value = emptyList()
    }

    fun loadPersistedTasks(context: Context) {
        val file = File(context.filesDir, STATE_FILE_NAME)
        if (!file.exists()) return
        runCatching {
            val content = file.readText()
            val array = JSONArray(content)
            val loaded = mutableListOf<DownloadTask>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val chunksArray = obj.optJSONArray("chunks") ?: JSONArray()
                val chunks = mutableListOf<ChunkRange>()
                for (c in 0 until chunksArray.length()) {
                    val cObj = chunksArray.getJSONObject(c)
                    chunks.add(
                        ChunkRange(
                            index = cObj.getInt("index"),
                            startByte = cObj.getLong("startByte"),
                            endByte = cObj.getLong("endByte"),
                            downloadedBytes = cObj.getLong("downloadedBytes")
                        )
                    )
                }
                val savedStatus = DownloadStatus.valueOf(obj.optString("status", DownloadStatus.PAUSED.name))
                val normalizedStatus = if (savedStatus == DownloadStatus.DOWNLOADING || savedStatus == DownloadStatus.MERGING || savedStatus == DownloadStatus.QUEUED) {
                    DownloadStatus.PAUSED
                } else {
                    savedStatus
                }
                loaded.add(
                    DownloadTask(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        sourceUrl = obj.getString("sourceUrl"),
                        directOrStreamUrl = obj.getString("directOrStreamUrl"),
                        fileName = obj.getString("fileName"),
                        destinationPath = obj.getString("destinationPath"),
                        formatLabel = obj.getString("formatLabel"),
                        formatSelector = obj.getString("formatSelector"),
                        mediaType = com.smartidm.downloader.model.MediaType.valueOf(
                            obj.optString("mediaType", com.smartidm.downloader.model.MediaType.VIDEO_MP4.name)
                        ),
                        useYoutubeDlEngine = obj.getBoolean("useYoutubeDlEngine"),
                        totalBytes = obj.getLong("totalBytes"),
                        downloadedBytes = obj.getLong("downloadedBytes"),
                        progressPercent = obj.optDouble("progressPercent", 0.0).toFloat(),
                        speedBytesPerSec = 0L,
                        etaSeconds = -1L,
                        threadCount = obj.optInt("threadCount", 4),
                        status = normalizedStatus,
                        statusDetail = normalizedStatus.arabicLabel,
                        errorMessage = obj.optString("errorMessage").takeIf { it.isNotEmpty() },
                        createdAtMillis = obj.optLong("createdAtMillis", System.currentTimeMillis()),
                        chunks = chunks
                    )
                )
            }
            _tasks.value = loaded
        }
    }

    @Synchronized
    fun persistTasks(context: Context) {
        runCatching {
            val array = JSONArray()
            _tasks.value.forEach { task ->
                val chunksJson = JSONArray()
                task.chunks.forEach { chunk ->
                    chunksJson.put(
                        JSONObject().apply {
                            put("index", chunk.index)
                            put("startByte", chunk.startByte)
                            put("endByte", chunk.endByte)
                            put("downloadedBytes", chunk.downloadedBytes)
                        }
                    )
                }
                val obj = JSONObject().apply {
                    put("id", task.id)
                    put("title", task.title)
                    put("sourceUrl", task.sourceUrl)
                    put("directOrStreamUrl", task.directOrStreamUrl)
                    put("fileName", task.fileName)
                    put("destinationPath", task.destinationPath)
                    put("formatLabel", task.formatLabel)
                    put("formatSelector", task.formatSelector)
                    put("mediaType", task.mediaType.name)
                    put("useYoutubeDlEngine", task.useYoutubeDlEngine)
                    put("totalBytes", task.totalBytes)
                    put("downloadedBytes", task.downloadedBytes)
                    put("progressPercent", task.progressPercent.toDouble())
                    put("threadCount", task.threadCount)
                    put("status", task.status.name)
                    put("errorMessage", task.errorMessage ?: "")
                    put("createdAtMillis", task.createdAtMillis)
                    put("chunks", chunksJson)
                }
                array.put(obj)
            }
            File(context.filesDir, STATE_FILE_NAME).writeText(array.toString())
        }
    }
}
