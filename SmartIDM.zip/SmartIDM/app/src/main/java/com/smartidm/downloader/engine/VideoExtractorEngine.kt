package com.smartidm.downloader.engine

import android.content.Context
import com.smartidm.downloader.data.DownloadRepository
import com.smartidm.downloader.model.DownloadStatus
import com.smartidm.downloader.model.ExtractedMediaInfo
import com.smartidm.downloader.model.VideoFormatOption
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.net.URI
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class VideoExtractorEngine(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onTaskChanged: () -> Unit
) {

    private val activeYtDlpJobs = ConcurrentHashMap<String, Job>()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    suspend fun analyzeUrl(rawUrl: String): Result<ExtractedMediaInfo> = withContext(Dispatchers.IO) {
        val cleanUrl = extractFirstUrl(rawUrl)
            ?: return@withContext Result.failure(IllegalArgumentException("يرجى إدخال رابط صالح يبدأ بـ http أو https"))

        if (isDirectMediaLink(cleanUrl)) {
            val headSize = fetchContentLengthSafe(cleanUrl)
            val fileName = guessFileNameFromUrl(cleanUrl)
            val ext = fileName.substringAfterLast('.', "mp4").lowercase()
            val directFormats = buildDirectFormats(cleanUrl, ext, headSize)
            return@withContext Result.success(
                ExtractedMediaInfo(
                    originalUrl = cleanUrl,
                    title = fileName.substringBeforeLast('.'),
                    uploader = extractHostName(cleanUrl),
                    durationSeconds = 0L,
                    thumbnailUrl = null,
                    isDirectFile = ext != "m3u8" && ext != "mpd",
                    formats = directFormats
                )
            )
        }

        // Try YoutubeDL extraction for platforms (YouTube, TikTok, Facebook, Instagram, X, etc.)
        try {
            val request = YoutubeDLRequest(cleanUrl).apply {
                addOption("--no-playlist")
                addOption("--socket-timeout", "20")
            }
            val streamInfo = YoutubeDL.getInstance().getInfo(request)
            val title = streamInfo.title?.takeIf { it.isNotBlank() } ?: "فيديو مستخرج_${System.currentTimeMillis() / 1000}"
            val uploader = streamInfo.uploader ?: extractHostName(cleanUrl)
            val duration = streamInfo.duration.toLong().coerceAtLeast(0L)
            val thumbnail = streamInfo.thumbnail

            val availableSizes = mutableMapOf<Int, Long>()
            streamInfo.formats?.forEach { f ->
                val h = f.height
                val size = if (f.fileSize > 0) f.fileSize else f.fileSizeApproximate
                if (h > 0 && size > 0) {
                    val current = availableSizes[h] ?: 0L
                    if (size > current) availableSizes[h] = size
                }
            }

            val options = listOf(
                VideoFormatOption(
                    id = "mp4_1080p",
                    title = "فيديو فائق الدقة (Full HD 1080p)",
                    resolution = "1080p MP4",
                    extension = "mp4",
                    formatSelector = "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/best[height<=1080][ext=mp4]/best[height<=1080]",
                    isAudioOnly = false,
                    estimatedSizeBytes = availableSizes[1080] ?: -1L
                ),
                VideoFormatOption(
                    id = "mp4_720p",
                    title = "فيديو عالي الدقة (HD 720p)",
                    resolution = "720p MP4",
                    extension = "mp4",
                    formatSelector = "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best[height<=720][ext=mp4]/best[height<=720]",
                    isAudioOnly = false,
                    estimatedSizeBytes = availableSizes[720] ?: -1L
                ),
                VideoFormatOption(
                    id = "mp4_480p",
                    title = "فيديو دقة متوسطة (SD 480p)",
                    resolution = "480p MP4",
                    extension = "mp4",
                    formatSelector = "bestvideo[height<=480][ext=mp4]+bestaudio[ext=m4a]/best[height<=480][ext=mp4]/best[height<=480]",
                    isAudioOnly = false,
                    estimatedSizeBytes = availableSizes[480] ?: -1L
                ),
                VideoFormatOption(
                    id = "mp3_audio",
                    title = "صوت نقي فقط (MP3 Audio 320kbps)",
                    resolution = "MP3 320kbps",
                    extension = "mp3",
                    formatSelector = "bestaudio/best",
                    isAudioOnly = true,
                    estimatedSizeBytes = -1L
                )
            )

            Result.success(
                ExtractedMediaInfo(
                    originalUrl = cleanUrl,
                    title = sanitizeFileName(title),
                    uploader = uploader,
                    durationSeconds = duration,
                    thumbnailUrl = thumbnail,
                    isDirectFile = false,
                    formats = options
                )
            )
        } catch (e: Throwable) {
            // Fallback preset formats so user can still queue the download via YoutubeDL or direct HTTP
            val fallbackTitle = guessFileNameFromUrl(cleanUrl).substringBeforeLast('.')
                .ifBlank { "وسائط_${System.currentTimeMillis() / 1000}" }
            val fallbackFormats = listOf(
                VideoFormatOption(
                    id = "mp4_1080p",
                    title = "فيديو فائق الدقة (Full HD 1080p)",
                    resolution = "1080p MP4",
                    extension = "mp4",
                    formatSelector = "bestvideo[height<=1080][ext=mp4]+bestaudio[ext=m4a]/best[height<=1080]/best",
                    isAudioOnly = false
                ),
                VideoFormatOption(
                    id = "mp4_720p",
                    title = "فيديو عالي الدقة (HD 720p)",
                    resolution = "720p MP4",
                    extension = "mp4",
                    formatSelector = "bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best[height<=720]/best",
                    isAudioOnly = false
                ),
                VideoFormatOption(
                    id = "mp4_480p",
                    title = "فيديو دقة متوسطة (SD 480p)",
                    resolution = "480p MP4",
                    extension = "mp4",
                    formatSelector = "bestvideo[height<=480][ext=mp4]+bestaudio[ext=m4a]/best[height<=480]/best",
                    isAudioOnly = false
                ),
                VideoFormatOption(
                    id = "mp3_audio",
                    title = "استخراج الصوت فقط (MP3 Audio)",
                    resolution = "MP3 HQ",
                    extension = "mp3",
                    formatSelector = "bestaudio/best",
                    isAudioOnly = true
                )
            )
            Result.success(
                ExtractedMediaInfo(
                    originalUrl = cleanUrl,
                    title = sanitizeFileName(fallbackTitle),
                    uploader = extractHostName(cleanUrl),
                    durationSeconds = 0L,
                    thumbnailUrl = null,
                    isDirectFile = false,
                    formats = fallbackFormats
                )
            )
        }
    }

    fun startYoutubeDlTask(taskId: String) {
        if (activeYtDlpJobs[taskId]?.isActive == true) return
        val job = scope.launch(Dispatchers.IO) {
            executeYoutubeDlDownload(taskId)
        }
        activeYtDlpJobs[taskId] = job
    }

    fun pauseOrStopYoutubeDlTask(taskId: String) {
        YoutubeDL.getInstance().destroyProcessById(taskId)
        activeYtDlpJobs.remove(taskId)?.cancel()
        DownloadRepository.updateTask(context, taskId, persistImmediately = true) { task ->
            task.copy(
                status = DownloadStatus.PAUSED,
                speedBytesPerSec = 0L,
                etaSeconds = -1L,
                statusDetail = "متوقف مؤقتاً (يدعم الاستئناف التلقائي عبر --continue)"
            )
        }
        onTaskChanged()
    }

    fun cancelYoutubeDlTask(taskId: String) {
        YoutubeDL.getInstance().destroyProcessById(taskId)
        activeYtDlpJobs.remove(taskId)?.cancel()
        val task = DownloadRepository.getTask(taskId)
        if (task != null) {
            runCatching {
                File(task.destinationPath).delete()
                File("${task.destinationPath}.part").delete()
            }
        }
        DownloadRepository.updateTask(context, taskId, persistImmediately = true) {
            it.copy(
                status = DownloadStatus.CANCELED,
                progressPercent = 0f,
                speedBytesPerSec = 0L,
                etaSeconds = -1L,
                statusDetail = "تم إلغاء التحميل"
            )
        }
        onTaskChanged()
    }

    private fun executeYoutubeDlDownload(taskId: String) {
        val task = DownloadRepository.getTask(taskId) ?: return
        try {
            DownloadRepository.updateTask(context, taskId, persistImmediately = true) {
                it.copy(
                    status = DownloadStatus.DOWNLOADING,
                    errorMessage = null,
                    statusDetail = "جارٍ التحميل عبر محرك YoutubeDL + FFmpeg..."
                )
            }
            onTaskChanged()

            val targetFile = File(task.destinationPath)
            targetFile.parentFile?.mkdirs()

            val request = YoutubeDLRequest(task.sourceUrl).apply {
                addOption("--no-playlist")
                addOption("--continue")
                addOption("--newline")
                addOption("--concurrent-fragments", task.threadCount.coerceIn(1, 8).toString())
                addOption("-o", targetFile.absolutePath)

                if (task.mediaType == com.smartidm.downloader.model.MediaType.AUDIO_MP3) {
                    addOption("-x")
                    addOption("--audio-format", "mp3")
                    addOption("--audio-quality", "0")
                } else {
                    addOption("-f", task.formatSelector)
                    addOption("--merge-output-format", "mp4")
                }
            }

            YoutubeDL.getInstance().execute(request, taskId) { progress, etaInSeconds, line ->
                val cleanProgress = progress.coerceIn(0f, 100f)
                val isMerging = line.contains("[Merger]", ignoreCase = true) ||
                        line.contains("[ExtractAudio]", ignoreCase = true) ||
                        line.contains("ffmpeg", ignoreCase = true)

                val currentStatus = if (isMerging) DownloadStatus.MERGING else DownloadStatus.DOWNLOADING
                val detailText = if (isMerging) {
                    "جارٍ دمج ومعالجة الوسائط بواسطة FFmpeg..."
                } else {
                    "جارٍ التحميل (${cleanProgress.toInt()}%)"
                }

                DownloadRepository.updateTask(context, taskId) { current ->
                    val currentFileLen = if (targetFile.exists()) targetFile.length() else current.downloadedBytes
                    current.copy(
                        status = currentStatus,
                        progressPercent = cleanProgress,
                        downloadedBytes = currentFileLen,
                        etaSeconds = etaInSeconds,
                        statusDetail = detailText
                    )
                }
                onTaskChanged()
            }

            val finalSize = if (targetFile.exists()) targetFile.length() else task.downloadedBytes
            DownloadRepository.updateTask(context, taskId, persistImmediately = true) {
                it.copy(
                    status = DownloadStatus.COMPLETED,
                    progressPercent = 100f,
                    downloadedBytes = finalSize,
                    totalBytes = if (finalSize > 0) finalSize else it.totalBytes,
                    speedBytesPerSec = 0L,
                    etaSeconds = 0L,
                    statusDetail = "اكتمل التحميل والدمج بنجاح"
                )
            }
            onTaskChanged()
        } catch (e: Throwable) {
            val current = DownloadRepository.getTask(taskId)
            if (current?.status == DownloadStatus.PAUSED || current?.status == DownloadStatus.CANCELED) {
                return
            }
            DownloadRepository.updateTask(context, taskId, persistImmediately = true) {
                it.copy(
                    status = DownloadStatus.FAILED,
                    speedBytesPerSec = 0L,
                    etaSeconds = -1L,
                    errorMessage = e.localizedMessage ?: "تعذر استخراج وتحميل الوسائط",
                    statusDetail = "فشل: ${e.localizedMessage ?: "خطأ في المعالجة"}"
                )
            }
            onTaskChanged()
        } finally {
            activeYtDlpJobs.remove(taskId)
        }
    }

    private fun buildDirectFormats(url: String, ext: String, contentLength: Long): List<VideoFormatOption> {
        return if (ext == "m3u8" || ext == "mpd") {
            listOf(
                VideoFormatOption(
                    id = "hls_1080p",
                    title = "بث مباشر فائق الدقة (1080p MP4 عبر FFmpeg)",
                    resolution = "1080p MP4",
                    extension = "mp4",
                    formatSelector = "bestvideo[height<=1080]+bestaudio/best[height<=1080]/best",
                    isAudioOnly = false
                ),
                VideoFormatOption(
                    id = "hls_720p",
                    title = "بث مباشر عالي الدقة (720p MP4 عبر FFmpeg)",
                    resolution = "720p MP4",
                    extension = "mp4",
                    formatSelector = "bestvideo[height<=720]+bestaudio/best[height<=720]/best",
                    isAudioOnly = false
                ),
                VideoFormatOption(
                    id = "hls_480p",
                    title = "بث مباشر دقة متوسطة (480p MP4 عبر FFmpeg)",
                    resolution = "480p MP4",
                    extension = "mp4",
                    formatSelector = "bestvideo[height<=480]+bestaudio/best[height<=480]/best",
                    isAudioOnly = false
                ),
                VideoFormatOption(
                    id = "hls_mp3",
                    title = "استخراج الصوت من البث (MP3 Audio)",
                    resolution = "MP3 HQ",
                    extension = "mp3",
                    formatSelector = "bestaudio/best",
                    isAudioOnly = true
                )
            )
        } else {
            listOf(
                VideoFormatOption(
                    id = "direct_multi_thread",
                    title = "تحميل مباشر فائق السرعة (تقسيم متعدد القنوات IDM)",
                    resolution = ext.uppercase(),
                    extension = ext,
                    formatSelector = "direct",
                    isAudioOnly = ext in listOf("mp3", "m4a", "wav", "aac", "ogg"),
                    estimatedSizeBytes = contentLength,
                    directUrl = url
                ),
                VideoFormatOption(
                    id = "direct_mp3_convert",
                    title = "تحويل واستخراج الصوت فقط (MP3 عبر FFmpeg)",
                    resolution = "MP3 320kbps",
                    extension = "mp3",
                    formatSelector = "bestaudio/best",
                    isAudioOnly = true,
                    estimatedSizeBytes = -1L
                )
            )
        }
    }

    private fun fetchContentLengthSafe(url: String): Long {
        return runCatching {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", MultiThreadDownloader.USER_AGENT)
                .head()
                .build()
            httpClient.newCall(req).execute().use { resp ->
                resp.header("Content-Length")?.toLongOrNull() ?: -1L
            }
        }.getOrDefault(-1L)
    }

    companion object {
        private val URL_REGEX = Regex("(https?://[^\s"'<>]+)", RegexOption.IGNORE_CASE)
        private val DIRECT_EXTENSIONS = setOf(
            "mp4", "m3u8", "webm", "mkv", "mov", "mp3", "m4a", "aac", "wav", "flac", "zip", "apk", "pdf"
        )

        fun extractFirstUrl(text: String): String? {
            val match = URL_REGEX.find(text.trim())
            return match?.value
        }

        fun isDirectMediaLink(url: String): Boolean {
            val path = runCatching { URI(url).path ?: "" }.getOrDefault(url.substringBefore("?"))
            val ext = path.substringAfterLast('.', "").lowercase()
            return ext in DIRECT_EXTENSIONS || url.contains(".m3u8", ignoreCase = true) || url.contains(".mp4", ignoreCase = true)
        }

        fun guessFileNameFromUrl(url: String): String {
            val path = runCatching { URI(url).path ?: "" }.getOrDefault(url.substringBefore("?"))
            val rawName = path.substringAfterLast('/').ifBlank { "media_${System.currentTimeMillis() / 1000}.mp4" }
            return sanitizeFileName(rawName)
        }

        fun extractHostName(url: String): String {
            return runCatching { URI(url).host ?: "رابط مباشر" }.getOrDefault("رابط ويب")
        }

        fun sanitizeFileName(name: String): String {
            return name.replace(Regex("[\\/:*?"<>|]"), "_").trim().take(110).ifBlank {
                "download_${System.currentTimeMillis() / 1000}"
            }
        }
    }
}
