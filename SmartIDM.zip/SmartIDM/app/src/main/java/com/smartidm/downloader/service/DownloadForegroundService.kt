package com.smartidm.downloader.service

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.smartidm.downloader.DownloaderApp
import com.smartidm.downloader.MainActivity
import com.smartidm.downloader.R
import com.smartidm.downloader.data.DownloadRepository
import com.smartidm.downloader.engine.MultiThreadDownloader
import com.smartidm.downloader.engine.VideoExtractorEngine
import com.smartidm.downloader.model.DownloadStatus
import com.smartidm.downloader.util.FormatUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

class DownloadForegroundService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private lateinit var multiThreadDownloader: MultiThreadDownloader
    private lateinit var videoExtractorEngine: VideoExtractorEngine

    override fun onCreate() {
        super.onCreate()
        multiThreadDownloader = MultiThreadDownloader(
            context = applicationContext,
            scope = serviceScope,
            onTaskChanged = ::refreshNotificationAndLifecycle
        )
        videoExtractorEngine = VideoExtractorEngine(
            context = applicationContext,
            scope = serviceScope,
            onTaskChanged = ::refreshNotificationAndLifecycle
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()

        val action = intent?.action ?: return START_STICKY
        val taskId = intent.getStringExtra(EXTRA_TASK_ID) ?: return START_STICKY
        val task = DownloadRepository.getTask(taskId)

        when (action) {
            ACTION_START_OR_RESUME -> {
                if (task != null) {
                    if (task.useYoutubeDlEngine) {
                        videoExtractorEngine.startYoutubeDlTask(taskId)
                    } else {
                        multiThreadDownloader.startOrResume(taskId)
                    }
                }
            }
            ACTION_PAUSE -> {
                if (task != null) {
                    if (task.useYoutubeDlEngine) {
                        videoExtractorEngine.pauseOrStopYoutubeDlTask(taskId)
                    } else {
                        multiThreadDownloader.pause(taskId)
                    }
                }
            }
            ACTION_CANCEL -> {
                if (task != null) {
                    if (task.useYoutubeDlEngine) {
                        videoExtractorEngine.cancelYoutubeDlTask(taskId)
                    } else {
                        multiThreadDownloader.cancel(taskId)
                    }
                }
            }
        }

        refreshNotificationAndLifecycle()
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val notification = buildSummaryNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun refreshNotificationAndLifecycle() {
        val allTasks = DownloadRepository.tasks.value
        val activeTasks = allTasks.filter {
            it.status == DownloadStatus.DOWNLOADING ||
                it.status == DownloadStatus.MERGING ||
                it.status == DownloadStatus.QUEUED
        }

        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (activeTasks.isEmpty()) {
            stopForeground(STOP_FOREGROUND_DETACH)
            manager.notify(NOTIFICATION_ID, buildSummaryNotification())
            stopSelf()
        } else {
            manager.notify(NOTIFICATION_ID, buildSummaryNotification())
        }
    }

    private fun buildSummaryNotification(): Notification {
        val allTasks = DownloadRepository.tasks.value
        val activeTasks = allTasks.filter {
            it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.MERGING
        }

        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (activeTasks.isEmpty()) {
            return NotificationCompat.Builder(this, DownloaderApp.DOWNLOAD_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(getString(R.string.app_name))
                .setContentText("لا توجد تحميلات نشطة حالياً")
                .setContentIntent(pendingIntent)
                .setOngoing(false)
                .build()
        }

        val totalSpeed = activeTasks.sumOf { it.speedBytesPerSec }
        val avgProgress = activeTasks.map { it.progressPercent }.average().toInt().coerceIn(0, 100)
        val primaryTitle = if (activeTasks.size == 1) {
            activeTasks.first().title
        } else {
            "جارٍ تحميل ${activeTasks.size} ملفات في الخلفية"
        }
        val speedText = if (totalSpeed > 0) " • ${FormatUtils.formatSpeed(totalSpeed)}" else ""

        return NotificationCompat.Builder(this, DownloaderApp.DOWNLOAD_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(primaryTitle)
            .setContentText("التقدم: $avgProgress%$speedText")
            .setProgress(100, avgProgress, false)
            .setContentIntent(pendingIntent)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 4091
        const val EXTRA_TASK_ID = "extra_task_id"
        const val ACTION_START_OR_RESUME = "com.smartidm.downloader.action.START_OR_RESUME"
        const val ACTION_PAUSE = "com.smartidm.downloader.action.PAUSE"
        const val ACTION_CANCEL = "com.smartidm.downloader.action.CANCEL"

        fun sendAction(context: Context, action: String, taskId: String) {
            val intent = Intent(context, DownloadForegroundService::class.java).apply {
                this.action = action
                putExtra(EXTRA_TASK_ID, taskId)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
