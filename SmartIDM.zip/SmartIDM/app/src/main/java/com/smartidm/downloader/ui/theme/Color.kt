package com.smartidm.downloader.ui.theme

import androidx.compose.ui.graphics.Color

val EmeraldPrimaryDark = Color(0xFF10B981)
val EmeraldOnPrimaryDark = Color(0xFF002114)
val EmeraldContainerDark = Color(0xFF064E3B)
val CyanSecondaryDark = Color(0xFF38BDF8)
val SlateBackgroundDark = Color(0xFF0B1120)
val SlateSurfaceDark = Color(0xFF111827)
val SlateCardDark = Color(0xFF1E293B)

val EmeraldPrimaryLight = Color(0xFF059669)
val EmeraldOnPrimaryLight = Color(0xFFFFFFFF)
val EmeraldContainerLight = Color(0xFFD1FAE5)
val CyanSecondaryLight = Color(0xFF0284C7)
val SlateBackgroundLight = Color(0xFFF8FAFC)
val SlateSurfaceLight = Color(0xFFFFFFFF)
val SlateCardLight = Color(0xFFF1F5F9)

val WarningAmber = Color(0xFFF59E0B)
val DangerRose = Color(0xFFF43F5E)
