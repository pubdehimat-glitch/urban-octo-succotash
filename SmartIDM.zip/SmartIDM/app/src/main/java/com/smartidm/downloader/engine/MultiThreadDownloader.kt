package com.smartidm.downloader.engine

import android.content.Context
import com.smartidm.downloader.data.DownloadRepository
import com.smartidm.downloader.model.ChunkRange
import com.smartidm.downloader.model.DownloadStatus
import com.smartidm.downloader.model.DownloadTask
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

class MultiThreadDownloader(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onTaskChanged: () -> Unit
) {

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    private val activeJobs = ConcurrentHashMap<String, Job>()

    fun startOrResume(taskId: String) {
        if (activeJobs[taskId]?.isActive == true) return
        val job = scope.launch(Dispatchers.IO) {
            executeMultiThreadDownload(taskId)
        }
        activeJobs[taskId] = job
    }

    fun pause(taskId: String) {
        activeJobs.remove(taskId)?.cancel()
        DownloadRepository.updateTask(context, taskId, persistImmediately = true) { task ->
            task.copy(
                status = DownloadStatus.PAUSED,
                speedBytesPerSec = 0L,
                etaSeconds = -1L,
                statusDetail = "تم الإيقاف المؤقت - جاهز للاستئناف"
            )
        }
        onTaskChanged()
    }

    fun cancel(taskId: String) {
        activeJobs.remove(taskId)?.cancel()
        val task = DownloadRepository.getTask(taskId)
        if (task != null) {
            runCatching { File(task.destinationPath).delete() }
        }
        DownloadRepository.updateTask(context, taskId, persistImmediately = true) { current ->
            current.copy(
                status = DownloadStatus.CANCELED,
                downloadedBytes = 0L,
                progressPercent = 0f,
                speedBytesPerSec = 0L,
                etaSeconds = -1L,
                chunks = emptyList(),
                statusDetail = "تم إلغاء التحميل"
            )
        }
        onTaskChanged()
    }

    fun isTaskRunning(taskId: String): Boolean = activeJobs[taskId]?.isActive == true

    private suspend fun executeMultiThreadDownload(taskId: String) {
        val initialTask = DownloadRepository.getTask(taskId) ?: return
        try {
            DownloadRepository.updateTask(context, taskId, persistImmediately = true) {
                it.copy(
                    status = DownloadStatus.DOWNLOADING,
                    errorMessage = null,
                    statusDetail = "جارٍ فحص الخادم وتقسيم الملف..."
                )
            }
            onTaskChanged()

            val probeResult = probeRemoteFile(initialTask.directOrStreamUrl)
            val totalLength = if (initialTask.totalBytes > 0) initialTask.totalBytes else probeResult.contentLength
            val supportsRanges = probeResult.acceptsRanges && totalLength > 256 * 1024L

            val destFile = File(initialTask.destinationPath)
            destFile.parentFile?.mkdirs()

            if (supportsRanges) {
                if (!destFile.exists() || destFile.length() != totalLength) {
                    RandomAccessFile(destFile, "rw").use { raf ->
                        raf.setLength(totalLength)
                    }
                }

                val threadCount = initialTask.threadCount.coerceIn(1, 8)
                val chunks = if (initialTask.chunks.isNotEmpty() && initialTask.totalBytes == totalLength) {
                    initialTask.chunks
                } else {
                    buildChunks(totalLength, threadCount)
                }

                val chunkProgressMap = ConcurrentHashMap<Int, Long>()
                chunks.forEach { chunk ->
                    chunkProgressMap[chunk.index] = chunk.downloadedBytes
                }

                val totalDownloadedAtomic = AtomicLong(chunks.sumOf { it.downloadedBytes })
                var lastReportTime = System.currentTimeMillis()
                var lastReportedBytes = totalDownloadedAtomic.get()

                DownloadRepository.updateTask(context, taskId, persistImmediately = true) {
                    it.copy(
                        totalBytes = totalLength,
                        downloadedBytes = totalDownloadedAtomic.get(),
                        chunks = chunks,
                        statusDetail = "جارٍ التحميل عبر $threadCount اتصالات متوازية..."
                    )
                }

                coroutineScope {
                    val deferreds = chunks.map { chunk ->
                        async(Dispatchers.IO) {
                            if (chunk.isComplete) return@async
                            downloadChunkRange(
                                url = initialTask.directOrStreamUrl,
                                destFile = destFile,
                                chunk = chunk,
                                onBytesRead = { deltaBytes, chunkTotalDownloaded ->
                                    chunkProgressMap[chunk.index] = chunkTotalDownloaded
                                    val currentTotal = totalDownloadedAtomic.addAndGet(deltaBytes)
                                    val now = System.currentTimeMillis()
                                    val elapsedMs = now - lastReportTime
                                    if (elapsedMs >= 450L) {
                                        synchronized(this@MultiThreadDownloader) {
                                            val recheckElapsed = now - lastReportTime
                                            if (recheckElapsed >= 450L) {
                                                val bytesDelta = currentTotal - lastReportedBytes
                                                val speed = if (recheckElapsed > 0) (bytesDelta * 1000L) / recheckElapsed else 0L
                                                val remaining = (totalLength - currentTotal).coerceAtLeast(0L)
                                                val eta = if (speed > 0) remaining / speed else -1L
                                                val updatedChunks = chunks.map { c ->
                                                    c.copy(downloadedBytes = chunkProgressMap[c.index] ?: c.downloadedBytes)
                                                }
                                                val progress = ((currentTotal.toDouble() / totalLength.toDouble()) * 100.0)
                                                    .toFloat()
                                                    .coerceIn(0f, 100f)

                                                DownloadRepository.updateTask(context, taskId) { task ->
                                                    task.copy(
                                                        totalBytes = totalLength,
                                                        downloadedBytes = currentTotal,
                                                        progressPercent = progress,
                                                        speedBytesPerSec = speed,
                                                        etaSeconds = eta,
                                                        chunks = updatedChunks,
                                                        statusDetail = "جارٍ التحميل (${threadCount} قنوات)"
                                                    )
                                                }
                                                lastReportTime = now
                                                lastReportedBytes = currentTotal
                                                onTaskChanged()
                                            }
                                        }
                                    }
                                }
                            )
                        }
                    }
                    deferreds.awaitAll()
                }

                val finalChunks = chunks.map { c ->
                    c.copy(downloadedBytes = (c.endByte - c.startByte + 1L))
                }
                DownloadRepository.updateTask(context, taskId, persistImmediately = true) {
                    it.copy(
                        downloadedBytes = totalLength,
                        totalBytes = totalLength,
                        progressPercent = 100f,
                        speedBytesPerSec = 0L,
                        etaSeconds = 0L,
                        status = DownloadStatus.COMPLETED,
                        chunks = finalChunks,
                        statusDetail = "اكتمل التحميل بنجاح"
                    )
                }
                onTaskChanged()
            } else {
                // Single-stream fallback when server does not support byte ranges
                downloadSingleStream(taskId, initialTask.directOrStreamUrl, destFile, totalLength)
            }
        } catch (ce: CancellationException) {
            DownloadRepository.persistTasks(context)
            throw ce
        } catch (e: Exception) {
            DownloadRepository.updateTask(context, taskId, persistImmediately = true) {
                it.copy(
                    status = DownloadStatus.FAILED,
                    speedBytesPerSec = 0L,
                    etaSeconds = -1L,
                    errorMessage = e.localizedMessage ?: "حدث خطأ في الاتصال بالخادم",
                    statusDetail = "فشل التحميل: ${e.localizedMessage ?: "خطأ في الشبكة"}"
                )
            }
            onTaskChanged()
        } finally {
            activeJobs.remove(taskId)
        }
    }

    private suspend fun downloadChunkRange(
        url: String,
        destFile: File,
        chunk: ChunkRange,
        onBytesRead: (delta: Long, chunkTotal: Long) -> Unit
    ) = coroutineScope {
        val resumeStart = chunk.currentOffset
        if (resumeStart > chunk.endByte) return@coroutineScope

        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Range", "bytes=$resumeStart-${chunk.endByte}")
            .build()

        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful && response.code != 206) {
                throw IllegalStateException("فشل استجابة الخادم للجزء ${chunk.index + 1}: HTTP ${response.code}")
            }
            val body = response.body ?: throw IllegalStateException("استجابة فارغة من الخادم")
            RandomAccessFile(destFile, "rw").use { raf ->
                raf.seek(resumeStart)
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                var chunkDownloaded = chunk.downloadedBytes
                body.byteStream().use { input ->
                    while (isActive) {
                        val read = input.read(buffer)
                        if (read == -1) break
                        raf.write(buffer, 0, read)
                        chunkDownloaded += read
                        onBytesRead(read.toLong(), chunkDownloaded)
                    }
                }
            }
        }
    }

    private suspend fun downloadSingleStream(
        taskId: String,
        url: String,
        destFile: File,
        knownTotalLength: Long
    ) = coroutineScope {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .build()

        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("خطأ من الخادم: HTTP ${response.code}")
            }
            val body = response.body ?: throw IllegalStateException("لا توجد بيانات للتحميل")
            val contentLength = if (knownTotalLength > 0) knownTotalLength else body.contentLength()

            var downloaded = 0L
            var lastTime = System.currentTimeMillis()
            var lastBytes = 0L

            destFile.outputStream().use { output ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                body.byteStream().use { input ->
                    while (isActive) {
                        ensureActive()
                        val read = input.read(buffer)
                        if (read == -1) break
                        output.write(buffer, 0, read)
                        downloaded += read

                        val now = System.currentTimeMillis()
                        val elapsed = now - lastTime
                        if (elapsed >= 450L) {
                            val speed = ((downloaded - lastBytes) * 1000L) / elapsed
                            val progress = if (contentLength > 0) {
                                ((downloaded.toDouble() / contentLength.toDouble()) * 100.0).toFloat().coerceIn(0f, 100f)
                            } else {
                                50f
                            }
                            val eta = if (contentLength > 0 && speed > 0) (contentLength - downloaded) / speed else -1L
                            DownloadRepository.updateTask(context, taskId) { task ->
                                task.copy(
                                    totalBytes = contentLength,
                                    downloadedBytes = downloaded,
                                    progressPercent = progress,
                                    speedBytesPerSec = speed,
                                    etaSeconds = eta,
                                    statusDetail = "جارٍ التحميل المباشر..."
                                )
                            }
                            lastTime = now
                            lastBytes = downloaded
                            onTaskChanged()
                        }
                    }
                }
            }

            DownloadRepository.updateTask(context, taskId, persistImmediately = true) { task ->
                task.copy(
                    totalBytes = if (contentLength > 0) contentLength else downloaded,
                    downloadedBytes = downloaded,
                    progressPercent = 100f,
                    speedBytesPerSec = 0L,
                    etaSeconds = 0L,
                    status = DownloadStatus.COMPLETED,
                    statusDetail = "اكتمل التحميل بنجاح"
                )
            }
            onTaskChanged()
        }
    }

    private fun buildChunks(totalBytes: Long, threadCount: Int): List<ChunkRange> {
        val chunkSize = totalBytes / threadCount
        return (0 until threadCount).map { index ->
            val start = index * chunkSize
            val end = if (index == threadCount - 1) totalBytes - 1 else (start + chunkSize - 1)
            ChunkRange(index = index, startByte = start, endByte = end, downloadedBytes = 0L)
        }
    }

    private fun probeRemoteFile(url: String): ProbeResult {
        runCatching {
            val rangeReq = Request.Builder()
                .url(url)
                .header("User-Agent", USER_AGENT)
                .header("Range", "bytes=0-0")
                .get()
                .build()

            okHttpClient.newCall(rangeReq).execute().use { response ->
                val code = response.code
                val contentRange = response.header("Content-Range")
                val acceptRanges = response.header("Accept-Ranges")
                if (code == 206 && contentRange != null && contentRange.contains("/")) {
                    val totalStr = contentRange.substringAfterLast("/").trim()
                    val total = totalStr.toLongOrNull() ?: -1L
                    return ProbeResult(contentLength = total, acceptsRanges = total > 0L)
                }
                val len = response.header("Content-Length")?.toLongOrNull() ?: -1L
                return ProbeResult(
                    contentLength = len,
                    acceptsRanges = acceptRanges?.equals("bytes", ignoreCase = true) == true
                )
            }
        }
        return ProbeResult(contentLength = -1L, acceptsRanges = false)
    }

    private data class ProbeResult(
        val contentLength: Long,
        val acceptsRanges: Boolean
    )

    companion object {
        private const val DEFAULT_BUFFER_SIZE = 32 * 1024
        const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36"
    }
}
