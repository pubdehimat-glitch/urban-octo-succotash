package com.smartidm.downloader

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.util.Log
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class DownloaderApp : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _isEngineReady = MutableStateFlow(false)
    val isEngineReady: StateFlow<Boolean> = _isEngineReady.asStateFlow()

    private val _engineStatusMessage = MutableStateFlow("جارٍ تهيئة محرك استخراج الفيديو و FFmpeg...")
    val engineStatusMessage: StateFlow<String> = _engineStatusMessage.asStateFlow()

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
        initializeMediaEngines()
    }

    private fun initializeMediaEngines() {
        applicationScope.launch {
            try {
                YoutubeDL.getInstance().init(this@DownloaderApp)
                FFmpeg.getInstance().init(this@DownloaderApp)
                _isEngineReady.value = true
                _engineStatusMessage.value = "محرك YoutubeDL و FFmpeg جاهز للعمل"
                Log.i(TAG, "YoutubeDL and FFmpeg initialized successfully")
            } catch (e: YoutubeDLException) {
                _isEngineReady.value = false
                _engineStatusMessage.value = "تعذر تهيئة YoutubeDL: ${e.localizedMessage ?: "خطأ غير معروف"}"
                Log.e(TAG, "Failed to initialize YoutubeDL/FFmpeg", e)
            } catch (e: Throwable) {
                _isEngineReady.value = false
                _engineStatusMessage.value = "وضع التحميل المباشر نشط (${e.localizedMessage ?: "تنبيه"})"
                Log.e(TAG, "Unexpected error initializing native libraries", e)
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                DOWNLOAD_CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        private const val TAG = "DownloaderApp"
        const val DOWNLOAD_CHANNEL_ID = "smart_idm_download_channel"

        @Volatile
        lateinit var instance: DownloaderApp
            private set
    }
}
